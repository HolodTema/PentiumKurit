package com.terabyte.timer001;

public class TimeFrame {
    public int hours, minutes, seconds;

    public TimeFrame(int hours, int minutes, int seconds) {
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = seconds;
    }

    public boolean isFinished() {
        return hours==0 & minutes==0 & seconds==0;
    }

    @Override
    public String toString() {
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    public int getProgress() {
        return hours*3600+minutes*60+seconds;
    }

    public void decrementTime() {
        if(seconds>0) {
            seconds--;
        }
        else {
            if(minutes>0) {
                minutes--;
                seconds = 59;
            }
            else {
                if(hours>0) {
                    hours--;
                    minutes = 59;
                    seconds = 59;
                }
            }
        }
    }
}
