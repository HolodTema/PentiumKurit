package com.terabyte.timer001;

import java.util.Calendar;

public class Constant {
    public static final int MODE_SLEEP = 0;
    public static final int MODE_RUN = 1;
    public static final int MODE_PAUSED = 2;

    public static final String INTENT_KEY_HOURS = "intentKeyHours";
    public static final String INTENT_KEY_MINUTES = "intentKeyMinutes";
    public static final String INTENT_KEY_SECONDS = "intentKeySeconds";

    public static final int SERVICE_ID = 1;
    public static final int NOTIFICATION_PENDING_INTENT_REQUEST_CODE = 0;
    public static final String NOTIFICATION_CHANNEL_ID = "notificationTimerId";
    public static final String NOTIFICATION_CHANNEL_NAME = "notificationTimerName";

    public static final String TIMER_NOTIFICATION_TITLE = "Timer";
}
