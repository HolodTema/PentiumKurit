package com.terabyte.timer001;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.sql.Time;

public class MainActivity extends AppCompatActivity {
    //sleep layout
    NumberPicker  numberPickerHours, numberPickerMinutes, numberPickerSeconds;
    //run layout
    TextView textRunningTimer;
    ProgressBar progressRunningTimer;
    int mode;
    TimerTask timerTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: 11.02.2022 we set mod by timer running
        mode = Constant.MODE_SLEEP;
        setSleepLayout();
    }

    public void onClickButtonStart(View view) {
        if(mode==Constant.MODE_SLEEP) {
            TimeFrame timeFrame = new TimeFrame(numberPickerHours.getValue(), numberPickerMinutes.getValue(), numberPickerSeconds.getValue());
            if(!timeFrame.isFinished()) {
                mode = Constant.MODE_RUN;
                setRunLayout(timeFrame);
                timerTask = new TimerTask();
                timerTask.execute(timeFrame);
            }
        }
    }

    public void onClickButtonPause(View view) {
        if(mode==Constant.MODE_RUN) {
            timerTask.isRunning = false;
            mode = Constant.MODE_PAUSED;
            setPausedLayout(timerTask.getTimeFrame());
        }
    }

    public void onClickButtonResume(View view) {
        if(mode==Constant.MODE_PAUSED) {
            TimeFrame timeFrame = timerTask.getTimeFrame();

            mode = Constant.MODE_RUN;
            setRunLayout(timeFrame);

            timerTask = new TimerTask();
            timerTask.execute(timeFrame);
        }
    }

    public void onClickButtonCancel(View view) {
        if(mode==Constant.MODE_RUN) {
            timerTask.isRunning = false;
            mode = Constant.MODE_SLEEP;
            setSleepLayout();
        }
        if(mode==Constant.MODE_PAUSED) {
            mode = Constant.MODE_SLEEP;
            setSleepLayout();
        }
    }

    private void setSleepLayout() {
        setContentView(R.layout.activity_main_sleep);
        numberPickerHours = findViewById(R.id.numberPickerHours);
        numberPickerMinutes = findViewById(R.id.numberPickerMinutes);
        numberPickerSeconds = findViewById(R.id.numberPickerSeconds);
        numberPickerHours.setMinValue(0);
        numberPickerMinutes.setMinValue(0);
        numberPickerSeconds.setMinValue(0);
        numberPickerHours.setMaxValue(99);
        numberPickerMinutes.setMaxValue(99);
        numberPickerSeconds.setMaxValue(99);
    }

    private void setRunLayout(TimeFrame timeFrame) {
        setContentView(R.layout.activity_main_run);
        textRunningTimer = findViewById(R.id.textRunningTimer);
        progressRunningTimer = findViewById(R.id.progressRunningTimer);

        textRunningTimer.setText(timeFrame.toString());
        progressRunningTimer.setMax(timeFrame.getProgress());
        progressRunningTimer.setProgress(timeFrame.getProgress());
    }

    private void setPausedLayout(TimeFrame timeFrame) {
        setContentView(R.layout.activity_main_paused);
        TextView textPausedTimer = findViewById(R.id.textPausedTimer);
        textPausedTimer.setText(timeFrame.toString());
    }

    class TimerTask extends AsyncTask<TimeFrame, TimeFrame, TimeFrame> {
        public boolean isRunning;
        private TimeFrame timeFrame;

        public TimerTask() {
            isRunning = true;
        }


        @Override
        protected TimeFrame doInBackground(TimeFrame... timeFrames) {
            timeFrame = timeFrames[0];
            long currTime1 = System.currentTimeMillis();
            while(isRunning) {
                long currTime2 = System.currentTimeMillis();
                if(currTime2-currTime1>=1000) {
                    currTime1 = System.currentTimeMillis();

                    timeFrame.decrementTime();
                    publishProgress(timeFrame);
                    if(timeFrame.isFinished()) {
                        isRunning = false;
                    }
                }
            }

            return timeFrame;
        }

        @Override
        protected void onProgressUpdate(TimeFrame... values) {
            super.onProgressUpdate(values);
            TimeFrame timeFrame = values[0];
            if(mode==Constant.MODE_RUN) {
                textRunningTimer.setText(timeFrame.toString());
                progressRunningTimer.setProgress(timeFrame.getProgress());
            }
        }

        @Override
        protected void onPostExecute(TimeFrame timeFrame) {
            super.onPostExecute(timeFrame);
            if(timeFrame.isFinished()) {
                //we are ringing
                mode = Constant.MODE_SLEEP;
                setSleepLayout();
                MediaPlayer mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.timer_sound);
                mediaPlayer.start();
            }
        }

        public TimeFrame getTimeFrame() {
            return timeFrame;
        }
    }
}